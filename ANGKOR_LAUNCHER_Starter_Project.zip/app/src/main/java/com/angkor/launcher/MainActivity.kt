package com.angkor.launcher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 17, 25)
    private val panel = Color.rgb(23, 31, 43)
    private val green = Color.rgb(65, 190, 125)
    private lateinit var versionSpinner: Spinner
    private lateinit var ramSpinner: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "⚒  ANGKOR"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "LAUNCHER  •  MINECRAFT JAVA EDITION"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())
        root.addView(space(24))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = rounded(panel, 20)
        }
        val heroTitle = TextView(this).apply {
            text = "YOUR JAVA WORLD"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val heroDesc = TextView(this).apply {
            text = "ជ្រើសរើស Version រួចរៀបចំការលេងរបស់អ្នក"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        hero.addView(heroTitle, matchWrap())
        hero.addView(space(8))
        hero.addView(heroDesc, matchWrap())
        root.addView(hero, matchWrap())
        root.addView(space(22))

        root.addView(section("GAME VERSION"))
        versionSpinner = spinner(listOf("1.21.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5", "1.12.2", "1.8.9"))
        root.addView(versionSpinner, matchWrap())
        root.addView(space(16))

        root.addView(section("MEMORY ALLOCATION"))
        ramSpinner = spinner(listOf("1024 MB", "2048 MB", "3072 MB", "4096 MB", "6144 MB"))
        root.addView(ramSpinner, matchWrap())
        root.addView(space(20))

        val play = Button(this).apply {
            text = "▶   PLAY MINECRAFT"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.rgb(8, 20, 15))
            background = rounded(green, 14)
            setOnClickListener {
                showMessage("នេះជាគំរូ UI ប៉ុណ្ណោះ។ Minecraft Engine មិនទាន់បានភ្ជាប់ទេ។")
            }
        }
        root.addView(play, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(space(10))

        val settings = Button(this).apply {
            text = "⚙   SETTINGS"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(42, 54, 69), 14)
            setOnClickListener {
                showMessage("Settings prototype: Version ${versionSpinner.selectedItem}, RAM ${ramSpinner.selectedItem}")
            }
        }
        root.addView(settings, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        root.addView(space(18))

        status = TextView(this).apply {
            text = "●  UI PROTOTYPE  |  ENGINE NOT CONNECTED"
            textSize = 11f
            setTextColor(Color.rgb(235, 185, 90))
            gravity = Gravity.CENTER
        }
        root.addView(status, matchWrap())
        root.addView(space(18))

        val footer = TextView(this).apply {
            text = "ANGKOR LAUNCHER • UNOFFICIAL COMMUNITY PROJECT"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        root.addView(footer, matchWrap())
        setContentView(scroll)
    }

    private fun section(s: String) = TextView(this).apply {
        text = s
        textSize = 12f
        letterSpacing = 0.1f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(green)
        setPadding(2, 0, 0, dp(8))
    }

    private fun spinner(items: List<String>): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.setPadding(dp(10), dp(4), dp(10), dp(4))
        return s
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
