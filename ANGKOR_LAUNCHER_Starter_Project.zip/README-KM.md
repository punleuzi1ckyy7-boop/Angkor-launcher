# ANGKOR LAUNCHER — Android UI Starter

នេះជាគម្រោង Android Studio ដំបូងសម្រាប់ UI របស់ ANGKOR LAUNCHER។
**វាមិនទាន់ជាអ្នកបើក Minecraft Java ពេញលេញទេ** ព្រោះមិនទាន់ភ្ជាប់ Java Runtime, native libraries, renderer និង launch engine។

## តម្រូវការ
- កុំព្យូទ័រដែលអាចដំឡើង Android Studio បាន
- Android Studio និង Android SDK Platform 35
- អ៊ីនធឺណិតសម្រាប់ Gradle ទាញយក dependencies

## របៀបបើក
1. Extract `ANGKOR_LAUNCHER.zip`
2. បើក Android Studio
3. ជ្រើស **Open** ហើយបើក folder `ANGKOR_LAUNCHER`
4. រង់ចាំ Gradle Sync
5. ភ្ជាប់ Android ទៅកុំព្យូទ័រ ឬបើក Emulator
6. ចុច **Run**

## របៀប Build APK
1. ក្នុង Android Studio ជ្រើស **Build**
2. ជ្រើស **Build Bundle(s) / APK(s)**
3. ជ្រើស **Build APK(s)**
4. APK debug នឹងបង្ហាញតាម notification របស់ Android Studio

## មុខងារដែលមានក្នុង Prototype
- ANGKOR LAUNCHER branded home screen
- Version selector (បង្ហាញជាជម្រើស UI ប៉ុណ្ណោះ)
- RAM selector (បង្ហាញជាជម្រើស UI ប៉ុណ្ណោះ)
- Play button បង្ហាញសារ Engine មិនទាន់ភ្ជាប់
- Settings prototype

## ជំហានបន្ទាប់ដើម្បីក្លាយជា Minecraft Java Launcher ពិត
ប្រើ Amethyst-Android ជា engine មូលដ្ឋាន ហើយអនុវត្ត branding/UI changes ដោយគោរព LGPLv3 និង licenses របស់ dependencies៖
https://github.com/AngelAuraMC/Amethyst-Android

Build instructions របស់ upstream៖
```bash
git clone --recursive https://github.com/AngelAuraMC/Amethyst-Android.git
cd Amethyst-Android
./gradlew :app_pojavlauncher:assembleDebug
```
Windows:
```powershell
.\gradlew.bat :app_pojavlauncher:assembleDebug
```
APK upstream build output:
`app_pojavlauncher/build/outputs/apk/debug/`

កុំចែកចាយ build ដែលបានកែប្រែដោយមិនពិនិត្យ license, notices, attribution និងលក្ខខណ្ឌចែកចាយរបស់ upstream/dependencies ជាមុន។
Minecraft គឺជាកម្មសិទ្ធិរបស់ Mojang/Microsoft។ ANGKOR LAUNCHER មិនមែនជាផលិតផលផ្លូវការរបស់ពួកគេទេ។
